#ifndef  PX4FLOW_H
#define PX4FLOW_H

#include "Dave3.h"
#include "../../_HAL/Delay/util.h"
#include "../../_HAL/I2C/I2Cdev.h"

#define PX_I2C_Handle I2C001_Handle1

struct PX4Flow_frame
{
    uint16_t frame_count;// counts created I2C frames [#frames]
    int16_t pixel_flow_x_sum;// latest x flow measurement in pixels*10 [pixels]
    int16_t pixel_flow_y_sum;// latest y flow measurement in pixels*10 [pixels]
    int16_t flow_comp_m_x;// x velocity*1000 [meters/sec]
    int16_t flow_comp_m_y;// y velocity*1000 [meters/sec]
    int16_t qual;// Optical flow quality / confidence [0: bad, 255: maximum quality]
    int16_t gyro_x_rate; // latest gyro x rate [rad/sec]
    int16_t gyro_y_rate; // latest gyro y rate [rad/sec]
    int16_t gyro_z_rate; // latest gyro z rate [rad/sec]
    uint8_t gyro_range; // gyro range [0 .. 7] equals [50 deg/sec .. 2000 deg/sec] 
    uint8_t sonar_timestamp;// time since last sonar update [milliseconds]
    int16_t ground_distance;// Ground distance in meters*1000 [meters].
    // Positive value: distance known. Negative value: Unknown distance
}PX4Flow;

#define PX4FLOW_ADDR (0x42 << 1 )
#define PX4_FLOW_MAXSIZE 22

uint8_t buf_px4_flow[PX4_FLOW_MAXSIZE] ;

void read_px4flow( struct PX4Flow_frame * frame);

#endif // ! PX4FLOW_H
