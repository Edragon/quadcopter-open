#include "px4flow.h"

void read_px4flow( struct PX4Flow_frame * frame)
{
    // Read from reg addr 0x00 and the frame length is 22 ;
	//uint8_t buf[PX4_FLOW_MAXSIZE] ;
    I2Cdev_readBytes((const I2C001Handle_type*)&PX_I2C_Handle, PX4FLOW_ADDR, 0x00, PX4_FLOW_MAXSIZE, buf_px4_flow );

    frame->frame_count = buf_px4_flow[1] << 8 | buf_px4_flow[0] ;
    frame->pixel_flow_x_sum = buf_px4_flow[3] << 8 | buf_px4_flow[2] ;
    frame->pixel_flow_y_sum = buf_px4_flow[5] << 8 | buf_px4_flow[4] ;
    frame->flow_comp_m_x =  buf_px4_flow[7] << 8 | buf_px4_flow[6] ;
    frame->flow_comp_m_y =  buf_px4_flow[9] << 8 | buf_px4_flow[8] ;
    frame->qual = buf_px4_flow[11] << 8 | buf_px4_flow[10] ;


//    frame->pixel_flow_y_sum = buf[5] << 8 | buf[4] ;
//    frame->flow_comp_m_x =  buf[7] << 8 | buf[6] ;
//    frame->flow_comp_m_y =  buf[9] << 8 | buf[8] ;
//    frame->qual = buf[11] << 8 | buf[10] ;

}
