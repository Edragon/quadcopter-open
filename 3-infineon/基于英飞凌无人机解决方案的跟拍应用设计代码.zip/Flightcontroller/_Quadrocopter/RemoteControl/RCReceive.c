/*
 * RCReceive.c
 *
 *  Created on: 22.12.2014
 *      Author: maan
 */

#include "RCReceive.h"
#include "../_HAL/GPIO.h"
#define BT_ONLY

#define VBat_LED_Green 	IO004_Handle0

////////////////////Variablen Elias///////////////////////////////
extern uint8_t* ReadBufBT;
extern ControlValue control_value;
extern DataPacket dpacket;
///////////////////////////////////////////////////////////////////

uint8_t BT_connected_flag = 0 ;
uint32_t RC_count = 0 ;

//Joystick values (range between -1 and 1, 0 in middle position)
float throttle = 0.0;
float rudder = 0.0;
float elevator = 0.0;
float aileron = 0.0;

//Bluetooth values
uint16_t throttleBT = 0;
uint8_t heightControlBT = 0;
float rudderBT = 0;
float aileronBT = 0;
float elevatorBT = 0;

uint8_t modeBT = 0;

uint8_t flightmode = 0;

uint8_t RCTimeOut = 1; //Timeout remote control 0:OK 1:TimeOut
uint8_t RCCount = 0; //Counter for RC read (used for TimeOut)

uint8_t BTTimeOut = 1;
uint8_t BTCount = 0;
_Bool conn = false;

// For pixy
int x_pixy = 0 , x_pixy_sum = 0;
int y_pixy = 0 , y_pixy_sum = 0;
int width_pixy = 0 , width_pixy_sum = 0;
int height_pixy = 0 , height_pixy_sum = 0;
int angle_pixy = 0;
int square_pixy = 0;
int distance_pixy = 0;
int x_pixy_raw, y_pixy_raw, square_pixy_raw;

uint8_t flag_pixy_detected = 0 ;
uint8_t count_pixy_detected = 0 ;

// Bluetooth transmission
uint8_t BT_trans_buf[16]= {0};

// extern
extern float Delta_pressure;
extern float powerD ;
extern float Delta_pressure ;
extern float rollD ;
extern float pitchD ;
extern uint8_t flag_pixy_detected;
// Software timer
handle_t TimerWatchRC; //Timer for RC watchdog

/*
 * Merge two bytes to one integer
 *
 * Parameters:
 * uint8_t a: high-byte
 * uint8_t b: low-byte
 *
 * Returnvalue:
 * int Merged bytes
 */
int mergeBytes(uint8_t a, uint8_t b)
{
	int c = a;
	return (c << 8) | b;
}

/**
 *Bluetooth Keep-Alive Messages
 * for Android-App to check connection
 */
void Bluetooth_Keep_Alive()
{
	//uint8_t keep_alive[] = "123456789012345\n";
	//UART001_WriteDataBytes(&BT_UART_Handle,(uint8_t*)&keep_alive,16);
	sprintf(BT_trans_buf, "%d %d %d %d\n", (int)Delta_pressure, (int)pitchD, (int)rollD , (int)powerD );
	UART001_WriteDataBytes(&BT_UART_Handle, BT_trans_buf, 16);
}
/**
 * Interrupt routine from UART FIFO in buffer
 * Buffer is full, new data is ready to read
 */
void RC_RECEIVE_ISR()
{
	uint8_t count = 0 , check_sum = 0;
	uint16_t check_sum_temp = 0 ;


	uint8_t ReadBufRC[32]; //Readbuffer
	int start = 0; //Index of start byte (contains 0x30)

	//Check if receive buffer interrupt is set
	if (UART001_GetFlagStatus(&RC_UART_Handle, UART001_FIFO_STD_RECV_BUF_FLAG)
			== UART001_SET)
	{
		//Read data from UART buffer
		UART001_ReadDataBytes(&RC_UART_Handle, ReadBufRC, 32);
		//Clear receive buffer interrupt flag
		UART001_ClearFlag(&RC_UART_Handle, UART001_FIFO_STD_RECV_BUF_FLAG);
		//Search for start byte and check static values
		while (ReadBufRC[start] != 0xAA || (ReadBufRC[start + 1] != 0x56 && ReadBufRC[start + 1] != 0x55))
		{

			if (start++ > 16)
			{
				//Communication check bytes not in buffer
				if(count_pixy_detected++ > 4 )
				{
					count_pixy_detected =0 ;
					flag_pixy_detected = 0 ;
				}
				return;
			}
		}

		check_sum_temp = 0;
		for(count = 0 ; count < 6 ; count ++ )
		{
			check_sum_temp += ReadBufRC[start + 2 * count + 5];
			check_sum = check_sum_temp & 0x00FF;

		}
		//Get data from stream
		if( check_sum == ReadBufRC[start + 3])
		{

			IO004_TogglePin(VBat_LED_Green);

			flag_pixy_detected = 1 ;
			count_pixy_detected = 0 ;

			x_pixy_sum += mergeBytes(ReadBufRC[start + 8] , ReadBufRC[start + 7]);
			y_pixy_sum += mergeBytes(ReadBufRC[start + 10] , ReadBufRC[start + 9]);
			width_pixy_sum += mergeBytes(ReadBufRC[start + 12] , ReadBufRC[start + 11]);
			height_pixy_sum += mergeBytes(ReadBufRC[start + 14] , ReadBufRC[start + 13]);



			angle_pixy = mergeBytes(ReadBufRC[start + 16] , ReadBufRC[start + 15]);
			RC_count ++ ;

			if( RC_count % 4 == 0) // ������RC_count
			{
				x_pixy = x_pixy_sum/4-158;
				y_pixy = -y_pixy_sum/4+98;
				width_pixy = width_pixy_sum/4;
				height_pixy = height_pixy_sum/4;

				if( width_pixy > height_pixy )
				{
					distance_pixy = 1000/width_pixy;
				}
				else
				{
					distance_pixy = 1000/height_pixy ;
				}

				x_pixy_sum = 0;
				y_pixy_sum = 0;
				width_pixy_sum = 0;
				height_pixy_sum = 0;
			}
		}
		else
		{
			// Check sum error counter
			if(count_pixy_detected++ > 4 )
			{
				count_pixy_detected = 0 ;
				flag_pixy_detected = 0 ;
			}
		}


		//Set values for RC Timeout check
		RCTimeOut = 0;
		RCCount++;
	}
}
void BT_RECEIVE_ISR()
{
	if (UART001_GetFlagStatus(&BT_UART_Handle, UART001_FIFO_STD_RECV_BUF_FLAG)
			== UART001_SET)
	{
		UART001_ReadDataBytes(&BT_UART_Handle,ReadBufBT,PACKET_SIZE);
		//Clear receive buffer interrupt flag
		UART001_ClearFlag(&BT_UART_Handle, UART001_FIFO_STD_RECV_BUF_FLAG);
		status_t rec_mode = maintainBluetoothInputBuffer(ReadBufBT,
				&control_value, &dpacket);
		switch (rec_mode)
		{
		case RECEIVED_CONTROL_PACKET:
			throttleBT = (uint16_t)*control_value.speed;
			heightControlBT = *control_value.height_control;
			aileronBT = *control_value.x_pitch*0.7;
			elevatorBT = -*control_value.y_roll*0.7;
			rudderBT = *control_value.z_rotate;
			BTTimeOut = 0;
			BTCount++;
			break;
		case RECEIVED_DATA_PACKET:
			break;
		case CHECKSUM_ERROR:
			throttleBT = 0;
			aileronBT = 0;
			elevatorBT = 0;
			rudderBT = 0;
			//Todo: Add Error-Handling
			break;
		case UNDEFINED_ERROR:

			throttleBT = 0;
			aileronBT = 0;
			elevatorBT = 0;
			rudderBT = 0;
			//undef_error++;
			//Todo: Add Error-Handling
			break;
		}
	}
}

/*
 * Check if new data has been arrived since last function call
 * This function is called from software Timer "TimerWatchRC"
 */
void WatchRC(void* Temp)
{
	static uint8_t lastCount;
	static uint8_t lastBTCount;

	if (lastCount == RCCount)
		RCTimeOut = 1;
	lastCount = RCCount;

	if (lastBTCount == BTCount)
		BTTimeOut = 1;
	lastBTCount = BTCount;

	//keep_alive packet for connection state_check
	//uint8_t keep_alive = 0xFF;
	//UART001_WriteDataBytes(&BT_UART_Handle, (uint8_t*) &keep_alive, 1);
}

/*
 * Initialize RC watchdog
 */
void WatchRC_Init()
{
	//Set timer to check every 500ms, if new data has arrived
	TimerWatchRC = SYSTM001_CreateTimer(200, SYSTM001_PERIODIC, WatchRC, NULL);
	if (TimerWatchRC != 0)
	{
		//Timer is created successfully
		if (SYSTM001_StartTimer(TimerWatchRC) == DAVEApp_SUCCESS)
		{
			//Timer started
		}
	}
}

uint8_t GetRCCount()
{
	return RCCount;
}

void GetRCData(float* power,uint8_t* height_control, float* yaw_dot, float* pitch, float* roll)
{
#ifdef BT_ONLY		//BT only controlled (no RC needed)
		if (BTTimeOut)
		{
			//*power = 0.0;
			//*yaw_dot = 0.0;
		//	*pitch = 0.0;
		//	*roll = 0.0;
			BT_connected_flag = 0 ;
		}
		else
		{
			BT_connected_flag = 1 ;
			/*
			*power = throttleBT;
			*height_control = heightControlBT;
			*pitch = elevatorBT;
			*roll = -aileronBT;
			*yaw_dot = rudderBT;
			*/
			if (*pitch > 30.0)
			{
				*pitch = 30.0;
			}
			else if (*pitch < -30.0)
			{
				*pitch = -30.0;
			}

			if (*roll > 30.0)
			{
				*roll = 30.0;
			}
			else if (*roll < -30.0)
			{
				*roll = -30.0;
			}
		}

#else		//for RC Control with switch to BT Control
	if (flightmode == 0)
		{
			if (RCTimeOut)
			{

				//*power = 0;
				*yaw_dot = 0;
				*pitch = 0;
				*roll = 0;

				BT_connected_flag = 0 ;
			}
			else
			{
				/*
				*power = SCALE_POWER * throttle;
				if (rudder > 0.01 || rudder < -0.01)
					*yaw_dot = rudder * SCALE_YAW;
				else
					*yaw_dot = 0;
					*pitch=elevator*SCALE_PITCH;
					*roll=-aileron*SCALE_ROLL;
				*/

				BT_connected_flag = 1 ;
			}
		}
	else
		{
			if (BTTimeOut || RCTimeOut)
			{
				*power = 0.0;
				*yaw_dot = 0.0;
				*pitch = 0.0;
				*roll = 0.0;
			}
			else
			{
				*power = throttleBT;
				*height_control = heightControlBT;
				*pitch = elevatorBT;
				*roll = -aileronBT;
				*yaw_dot = rudderBT;
				if (*pitch > 30.0)
				{
					*pitch = 30.0;
				}
				else if (*pitch < -30.0)
				{
					*pitch = -30.0;
				}

				if (*roll > 30.0)
				{
					*roll = 30.0;
				}
				else if (*roll < -30.0)
				{
					*roll = -30.0;
				}
			}
		}
#endif
}

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
