/*
 * Main.c
 *
 *  Created on: 25.12.2014
 *      Author: Andreas
 */

//----------------------------------------------------------------------------
//
//					LARIX Flight Controller Software with DPS310
//				(compatible with Flight Controller App V2.0 or higher)
//
//----------------------------------------------------------------------------
//
//		Default Mode: RC controlled with switch for Bluetooth-App Control
//		(for Bluetooth only Version "#define BT_ONLY" in the RCReceive.h)
//
//----------------------------------------------------------------------------


#include <DAVE3.h>			//Declarations from DAVE3 Code Generation (includes SFR declaration)
#include <limits.h>
#include "_Quadrocopter/_HAL/Delay/util.h"
#include "_Quadrocopter/_HAL/I2C/I2Cdev.h"
#include "_Quadrocopter/Sensors/MPU9X50/MPU9150.h"
#include "_Quadrocopter/Sensors/DPS310/DPS310.h"

#include "_Quadrocopter/RemoteControl/RCReceive.h"
#include "_Quadrocopter/Attitude_Control/Attitudecontroller.h"
#include "_Quadrocopter/DaisyChain/DaisyChain.h"

#include "_Quadrocopter/_FIR_Filter/FIR_Filter.h"

#include "_Quadrocopter/BatterySafety/BatterySafety.h"

#include "_Quadrocopter/Sensors/DPS310/px4flow.h"

//Define which Frame is used:
//++++++++++++++++++++++++++++++++++++++++
	#define Plexi
//	#define ROLL_TO_LR
//++++++++++++++++++++++++++++++++++++++++
///////////////////////////////////////////////P=1 I=0.005������ P=0.8 I=0.004�𵴣����ڳ�//P=0.4,I=0.002��max=2000��base=73 ok
//���ܱ����P=0.3,I=0.002��max=1500��base=113-4*VBat ok
#define Kp_pressure 0.3
#define Ki_pressure 0.0013
#define Kd_pressure 2
float Height_desire = 0;

#define Kp_pitch 0.2
#define ANGLE_DESIRE_MIN -6.0
#define Balance_error_pitch 0.0

#define ANGLERATE_K -0.3
#define ANGLERATE_MAX 50.0
#define ANGLERATE_MIN -50.0

#define kp_px4flow_x 0.15   //0.15
#define kp_px4flow_y 0.15
#define ki_px4flow_x 0.008  //0.005
#define ki_px4flow_y 0.008
#define kd_px4flow_x 0.00
#define kd_px4flow_y 0.00
////////////////////////////////////////////////

///////////////////////////////////////////////
#define CONTROL_ORDER 2
//Actor values
float PWM_percent[] = {0.0, 0.0, 0.0, 0.0};

float x_pitch[CONTROL_ORDER];
float x_roll[CONTROL_ORDER];

float u_yaw_dot = 0.0;
float u_pitch = 0.0;
float u_roll = 0.0;
//------------------------------------------------------------------------
//Controllerparamter for Carbon
#ifdef Carbon
const float T=0.002;
const float P_roll = 125.0;		//for Carbon: 125.0;
const float I_roll = 0.0;		//for Carbon: 0.2;
const float D_roll =  4.0;		//for Carbon: 4.0;
const float N_roll = 400.0;		//for Carbon: 400.0;
const float P_pitch = 125.0;	//for Carbon: 125.0;
const float I_pitch = 0.0;		//for Carbon: 0.2;
const float D_pitch = 4.0;		//for Carbon: 4.0;
const float N_pitch = 400.0;	//for Carbon: 400.0;
const float P_yaw = -200.0;		//for Carbon: 40.0;
#endif
//------------------------------------------------------------------------
//Controllerparamter for Plexi
#ifdef Plexi
const float T=0.002;
const float P_roll = 70.0;		//for Plexi: 70.0
const float I_roll = 0.2;		//for Plexi: 0.2
const float D_roll =  1.7;		//for Plexi: 1.7
const float N_roll = 400.0;		//for Plexi: 400.0
const float P_pitch = 70.0;		//for Plexi: 70.0
const float I_pitch = 0.2;		//for Plexi: 0.2
const float D_pitch = 1.7;		//for Plexi: 1.7
const float N_pitch = 400.0;	//for Plexi: 400.0
const float P_yaw = -200.0;		//for Plexi: 200.0
#endif
//------------------------------------------------------------------------

// For pixy
extern int x_pixy ;
extern int y_pixy ;
extern int width_pixy ;
extern int height_pixy ;
extern int angle_pixy ;
extern int x_pixy_raw ;
extern int y_pixy_raw ;
extern int square_pixy_raw ;
extern int distance_pixy ;

extern uint8_t flag_pixy_detected ;
extern int square_pixy ;
extern uint32_t RC_count ;
extern struct PX4Flow_frame PX4Flow;
extern uint8_t buf_px4_flow[];

struct structFIR PixyS_FIR ;
struct structFIR PixyX_FIR ;
struct structFIR PixyY_FIR ;



// Bluetooth
extern uint8_t BT_trans_buf[16] ;

//Controllerpolynomials
float a_roll[CONTROL_ORDER];
float a_pitch[CONTROL_ORDER];
float b_roll[CONTROL_ORDER+1];
float b_pitch[CONTROL_ORDER+1];

//Remote Control
float powerD = 0.0;
uint8_t height_control = 0;		// 0xFF when activated
float yawD_dot = 0.0;
float pitchD = 0.0;
float rollD = 0.0;



float YPR[3];
float sensorData[3];

//PX4FLOW
int px4flow_x = 0 ;
int px4flow_y = 0 ;
int px4flow_x_sum = 0 ;
int px4flow_y_sum = 0 ;
float px4flow_x_last = 0.0;
float px4flow_y_last = 0.0;
float px4flow_x_d = 0.0;
float px4flow_y_d = 0.0;
float px4flow_x_i = 0.0;
float px4flow_y_i = 0.0;
int td_px4flow_count = 0;

float pitch_last = 0.0 ;
float roll_last = 0.0 ;
float pitch_delta = 0.0 ;
float roll_delta = 0.0 ;

float px4flow_y_desire = 0.0 ;
//����
float pitch_init = 0.0 ;
float roll_init = 0.0 ;

//DPS3100 Pressure-Sensor
float pressure = 0;
float pressure_last = 101650;
float temperature = 0;
struct structFIR PressureFIR;

float init_pressure = 0 ;
float pressure_desired = 0 ;
float Delta_pressure_sum = 0 ;
extern uint8_t BT_connected_flag ;
float Delta_pressure;
float Delta_pressure_d = 0;
float Delta_pressure_d_filt = 0 ;
int PID_ts_count = 0;
///////////kalman
float P_Kalman = 1 ;
//int mean_count = 0 ;
//float d_sum = 0 ;
//float d_error_square = 0;
//float d_error_square_sum = 0;
//float d_mean = 0;


int8_t TxBuffer[100] = { 0 };
char c[100]; //for displaying data

//Battery Safety
float VBat = 0;
bool sendMag = FALSE;
uint16_t counter_main=0;
int8_t MonitorBuffer[14] = {0};
int8_t MotorRunning=0;

void Monitoring_Int_Handler();
float Kalman(float x1 , float x2 , float Q);

void Update_Pixy_Direction()
{
	if (flag_pixy_detected != 0)
	{


		//
		if(x_pixy > 158)
			x_pixy = 158;
		if(x_pixy < -158)
			x_pixy = -158;
		if(y_pixy > 98)
			y_pixy = 98;
		if(y_pixy < -98)
			y_pixy = -98;
		//


//		if(td_pixy_count>4)
//		{
//			x_pixy_d = x_pixy-x_pixy_last;
//			y_pixy_d = y_pixy-y_pixy_last;
//			x_pixy_last = x_pixy;
//			y_pixy_last = y_pixy;
//			td_pixy_count = 0;
//		}


//		td_pixy_count++;


		//x_pixy = (int)(FIR_FILTER(&PixyX_FIR, (float)(x_pixy_raw))) ;
		//y_pixy = (int)FIR_FILTER(&PixyX_FIR, (float)(y_pixy_raw));

		#ifdef ROLL_TO_LR
			rollD = ANGLE_DESIRE_MAX*x_pixy/100 ;




			if(rollD > ANGLE_DESIRE_MAX  )
			{
				rollD = ANGLE_DESIRE_MAX;
			}
			else if( rollD < ANGLE_DESIRE_MIN)
			{
				rollD = ANGLE_DESIRE_MIN ;
			}
		#else
			yawD_dot = ANGLERATE_K * x_pixy ;
			if(yawD_dot > ANGLERATE_MAX )
			{
				yawD_dot = ANGLERATE_MAX ;
			}
			else if(yawD_dot < ANGLERATE_MIN )
			{
				yawD_dot = ANGLERATE_MIN ;
			}



		#endif


		px4flow_y_desire = Kp_pitch*(distance_pixy-50.0);

		if(px4flow_y_desire > 5  )
		{
			px4flow_y_desire = 5 ;
		}
		else if(px4flow_y_desire < -5 )
		{
			px4flow_y_desire = -5 ;
		}

		if ( Height_desire<15 )
		{
			Height_desire += 0.1 ;
		}
		else if (Height_desire>15)
		{
			Height_desire = 15;
		}
	}
	else
	{
		if ( Height_desire<15 )
		{
			Height_desire += 0.1 ;
		}
		else if (Height_desire>15)
		{
			Height_desire = 15;
		}
		yawD_dot = 0 ;
		px4flow_y_desire = 0 ;
		//////////////

	}

}
void Update_Desire(void)
{
	float powerD_new;

	updateValues(&pressure, &temperature);


    if((pressure_last-pressure)<50)
    {
    	Delta_pressure_d = pressure-pressure_last;
 //   	PID_ts_count++;
    	Delta_pressure = (pressure+pressure_last)/2 - pressure_desired;//error
    	Delta_pressure_sum += Delta_pressure; //I
    	pressure_last=pressure;
    }

    /*

    d_sum += Delta_pressure_d;
    mean_count ++;
    if(mean_count == 200)
    {
    	d_mean = d_sum/200;
    	mean_count	= 0 ;
    	d_error_square = d_error_square_sum/200;
    	d_error_square_sum = 0 ;
    }

    d_error_square_sum += (Delta_pressure_d-d_mean)*(Delta_pressure_d-d_mean);
    */
    Delta_pressure_d_filt = Kalman( Delta_pressure_d_filt ,Delta_pressure_d , 0.2);

    if (Delta_pressure_sum > 6000)
    {
    	Delta_pressure_sum = 6000;
    }
    if (Delta_pressure_sum < -6000)
    {
       	Delta_pressure_sum = -6000;
    }

   if( VBat>9.5 )
    {
    	powerD_new = 108-4*VBat+Kp_pressure * Delta_pressure + Ki_pressure *  Delta_pressure_sum + Kd_pressure *  Delta_pressure_d;//
    }

    else
    {
    	powerD_new = 0;//74+Kp_pressure * Delta_pressure + Ki_pressure *  Delta_pressure_sum;
    }


    if ((powerD_new-powerD)>1)
    {
    	powerD+=1;
    }
    else if ((powerD_new-powerD)<-1)
    {
        powerD-=1;
    }
    else
    {
    	powerD= powerD_new ;
    }

    if(powerD > 85.0)
    {
    	powerD = 85.0 ;
    }

}

void Controller_CompareMatch_Int_Handler(void)
{
	static uint8_t update_desire_count = 0 ;
	static uint8_t update_px4flow = 0 ;

	 if(BT_connected_flag == 1)
	   {
		Update_Pixy_Direction();

		if(powerD < 15)
		{
			powerD+=0.05;
		}
		if(powerD <= 50 &&  powerD >= 15)
		{
			powerD+=0.1;
		}

		if((update_desire_count >= 9)&&(powerD >= 50 ))
		{
		    pressure_desired = init_pressure - Height_desire ;
			update_desire_count = 0 ;
			Update_Desire();
		}
		else
		{
			update_desire_count ++ ;
		}

		read_px4flow(&PX4Flow);
		px4flow_x_sum += PX4Flow.pixel_flow_x_sum ;
		px4flow_y_sum += PX4Flow.pixel_flow_y_sum ;

		if( update_px4flow ++ == 5 )      //20Hz
		{
			px4flow_x = px4flow_x_sum/5;
			px4flow_y = px4flow_y_sum/5;
			px4flow_x_sum = 0;
			px4flow_y_sum = 0;
			update_px4flow = 0 ;

			px4flow_x_i += ki_px4flow_x*px4flow_x;
			px4flow_y_i += ki_px4flow_y*(px4flow_y- px4flow_y_desire);

			if(px4flow_x_i > 4)
				px4flow_x_i = 4;
			else if(px4flow_x_i < -4)
				px4flow_x_i = -4;
			if(px4flow_y_i > 4)
				px4flow_y_i = 4;
			else if(px4flow_y_i < -4)
				px4flow_y_i = -4;

			rollD = (kp_px4flow_x * px4flow_x + kd_px4flow_x*px4flow_x_d+ px4flow_x_i );//+ kp_roll_compen_px4 * roll_delta );
			pitchD = -(kp_px4flow_y * (px4flow_y - px4flow_y_desire) + kd_px4flow_y*px4flow_y_d+ px4flow_y_i);// - kp_pitch_compen_px4 * pitch_delta);

			if(rollD > 6)
				rollD = 6;
			else if(rollD < -6)
				rollD = -6;
			if(pitchD > 6)
				pitchD = 6;
			else if(pitchD < -6)
				pitchD = -6;
		}
	}

	else
	{
		if(powerD > 1.0 )
		{
			powerD -= 0.2 ;
		}
	//	if(counter_main % 10 == 0)
		{
	//	   updateValues(&init_pressure, &temperature);
		}
		pressure_last = init_pressure ;
		Delta_pressure_sum = 0 ;
		px4flow_x_i = 0 ;
		px4flow_y_i = 0 ;
	//	PID_ts_count = 0;
	}

	if(YPR[1]>60||YPR[2]>60||YPR[1]<-60||YPR[2]<-60)
	{
		powerD=0;
	}

	GetAngles(YPR);
	GetRCData(&powerD, &height_control, &yawD_dot, &pitchD, &rollD);
	//yaw control
	AngleRateController(&yawD_dot, &YPR[0], &P_yaw, &u_yaw_dot);
	//pitch control
	AngleController(&pitchD, &YPR[1], CONTROL_ORDER, a_pitch, b_pitch, x_pitch, &u_pitch);
	//roll control
	AngleController(&rollD, &YPR[2], CONTROL_ORDER, a_roll, b_roll, x_roll, &u_roll);

	//generate actuator values
	CreatePulseWidth(&u_roll, &u_pitch, &u_yaw_dot, &powerD, PWM_percent);

	if (powerD > 5.0)
		SendDaisyData(SET_REF_CURRENT,
			PWM_percent[2]/100.0*1279,
			PWM_percent[0]/100.0*1279,
			PWM_percent[1]/100.0*1279,
			PWM_percent[3]/100.0*1279);
	else
		SendDaisyData(STOP_MOTOR,0,0,0,0);

	counter_main++;
}

void Initialize()
{

	initBluetoothStorage();
	delay(1000);
    // initialize device
	MPU9150_Setup();
	delay(1000);

    // initilize controller polynomials
	b_roll[0]=P_roll-I_roll*T-P_roll*N_roll*T+N_roll*I_roll*T*T+D_roll*N_roll;
	b_roll[1]=I_roll*T-2*P_roll+P_roll*N_roll*T-2*D_roll*N_roll;
	b_roll[2]=P_roll+D_roll*N_roll;
	a_roll[0]=1-N_roll*T;
	a_roll[1]=N_roll*T-2;

	b_pitch[0]=P_pitch-I_pitch*T-P_pitch*N_pitch*T+N_pitch*I_pitch*T*T+D_pitch*N_pitch;
	b_pitch[1]=I_pitch*T-2*P_pitch+P_pitch*N_pitch*T-2*D_pitch*N_pitch;
	b_pitch[2]=P_pitch+D_pitch*N_pitch;
	a_pitch[0]=1-N_pitch*T;
	a_pitch[1]=N_pitch*T-2;

	WatchRC_Init(); //Initialize RC watchdog

	//initialize DPS310
	setupDPS310();
	getCoefficients();

	//initialize FIR Filter
	//PressureFIR = Initialize_FIR_Filter(PressureFIR, MOVING_AVERAGE);
	//PixyX_FIR = Initialize_FIR_Filter(PixyX_FIR, MOVING_AVERAGE);
	//PixyY_FIR = Initialize_FIR_Filter(PixyY_FIR, MOVING_AVERAGE);
	//PixyS_FIR = Initialize_FIR_Filter(PixyS_FIR, MOVING_AVERAGE);

	delay(2000);


    //I2Cdev_readByte((const I2C001Handle_type*)&DPS310_I2C_Handle,DPS310_Address,0x0A);

	updateValues(&init_pressure, &temperature);

	PWMSP001_Start(&PWMSP001_Handle0);
}

int main(void)
{
	uint16_t Bytes = 0;
	uint16_t nByte;
//	uint8_t send_i = 0;
//	status_t status;		// Declaration of return variable for DAVE3 APIs (toggle comment if required)

	DAVE_Init();			// Initialization of DAVE Apps
	USBVC001_Init();		//Initialize the USB core in Device mode

	Initialize();

	while(1)
	{

	    //------------------------------------------------------------------------------------------------------------------------------
		//		for serial communication (USB)

		// Check number of bytes received
	    Bytes = USBVC001_BytesReceived();

	    if(Bytes != 0)
	    {
	    	for(nByte = 0; nByte < Bytes; nByte++)
	    	{
	    		// Receive Byte
	    		if(USBVC001_ReceiveByte(&TxBuffer[0]) != DAVEApp_SUCCESS)
	    		{
	    			//Error
	    		}
	    	}
			switch(TxBuffer[0])
			{
				case '1':
					sprintf(c, "powerD: %f YawD: %f PitchD: %f RollD: %f Flag_pixy:%d\n", powerD, yawD_dot, pitchD, rollD, flag_pixy_detected);
					break;
				case '2':
					sprintf(c, "count:%d x_sum:%d y_sum:%d m_x:%d m_y:%d qual:%d\n",PX4Flow.frame_count,px4flow_x,px4flow_y,PX4Flow.flow_comp_m_x,PX4Flow.flow_comp_m_y,PX4Flow.qual );
//					{
//						for(send_i = 0 ; send_i < 22 ; send_i ++ )
//						{
//							sprintf(c , "%x ", buf_px4_flow[send_i] );
//							USBVC001_SendString((const char *)c);
//						}
//						sprintf(c , "END\n");
//						break;
//						//PWMSP001_Start(&PWMSP001_Handle2);
//						//break;
//					}
					break;
				case '3':
					sprintf(c, "Y:%1.2f P:%1.2f R:%1.2f dP:%1.2f dR:%1.2f\n", YPR[0], YPR[1], YPR[2],pitch_delta,roll_delta);
					break;
				case '4':
					sprintf(c, "PWM1:%f PWM2:%f PWM3:%f PWM4:%f\n", PWM_percent[0], PWM_percent[1], PWM_percent[2], PWM_percent[3]);
					break;
				case '5':
					sprintf(c, "eY:%f eP:%f eR:%f\n", yawD_dot-YPR[0], pitchD-YPR[1], rollD-YPR[2]);
					break;
				case '6':
					//sprintf(c, "dP:%f dI:%f dd:%f fd:%f P:%f I:%f D:%f PowerD:%f T_count:%d  \n", Delta_pressure,Delta_pressure_sum,Delta_pressure_d,Delta_pressure_d_filt,Kp_pressure*Delta_pressure,Ki_pressure*Delta_pressure_sum,Kd_pressure*Delta_pressure_d_filt,powerD,PID_ts_count);
					sprintf(c, "TimerSensor:%d TimerMain:%d TimerRC:%d\n", (int)GetSensorCount(), (int)counter_main, (int)GetRCCount());
					break;
				case '7':
					GetGyroData(sensorData);
					sprintf(c, "GyroX:%3.2f GyroY:%3.2f GyroZ:%3.2f\n", sensorData[0], sensorData[1], sensorData[2]);
					break;
				case '8':
					GetAccData(sensorData);
					sprintf(c, "AccX:%f AccY:%f AccZ:%f\n", sensorData[0], sensorData[1], sensorData[2]);
					break;
				case '9':
					sprintf(c, "Pressure:%f Temperature:%f InitPressure:%f BT:%d\n", pressure, temperature, init_pressure, BT_connected_flag);
					break;
				case '0':
					//sprintf(c, "VBat:%0.2f\n", VBat);
					sprintf(c, "Pixy: x:%d  y:%d  w:%d  h:%d d:%d A:%d N:%d VBat:%0.2f\n", x_pixy, y_pixy, width_pixy, height_pixy, distance_pixy, angle_pixy, RC_count, VBat);
					break;
			}
			USBVC001_SendString((const char *)c);
	    }
	    if (sendMag)
	    {
	    	sendMag = FALSE;
	    	USBVC001_SendString((const char *)c);
	    }
	    // Call continuous to handle class specific control request
	    USB_USBTask();
	    //------------------------------------------------------------------------------------------------------------------------------
	}
	return 0;
}

void Mag_Calibration_Int_Handler()
{
    GetMagData(sensorData);
    sprintf(c, "%f,%f,%f\r\n", sensorData[0], sensorData[1], sensorData[2]);
    sendMag = TRUE;
}

float Kalman(float x1 , float x2 , float Q)//x1Ϊ��һ������ֵ��x2Ϊ����ֵ
{
	float y = 0 ;//���
	float kg = 0 ;

	kg = P_Kalman/(P_Kalman+0.06); //����
	y = kg*(x2-x1)+x1;
	P_Kalman = (1-kg)*P_Kalman+Q;

    return y;
}
